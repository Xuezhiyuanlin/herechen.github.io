---
date: 2014-03-04 19:08:04
creatdate: 2014-03-04 19:08:04
layout: post
title: 我的第一个博客
thread: 1
categories: 日志
tags: 日志
---

## 背景
这个博客用jekyll搭建,放在github上.

## 过程
- jekyll版本号1.4.2, 1.4.3搭配Ruby 2.0.0不能本地用server.
- gem 2.2.2.
- Ruby和DevKit都用installer直接安装，x64版本.
- 系统Windows x64.

## 感受
折腾,折腾,折腾

## 时间
2014年2月伊始,今日2014年3月4日

