[HereChen](http://herechen.github.io) 的博客

本博客运行于 Jekyll @ GitHub，博客模板修改自 [Yonsm.NET](https://github.com/Yonsm/NET) 的博客。对于原模版功能上的增加包括菜单浮动和文章目录浮动，并修改了 RSS 订阅。

稍作修改后的博客并不是完全通用的，如果你要直接使用此博客，需要注意要修改的地方：

- 在 `_layout/default.html` 中 `footer` 部分含有个人信息
- 在 `about/index.md` 中有个人信息
- 删除 `_post` 中的个人博客
- `guestbook/index.md` 中关于图片的语句
- `links/index.md` 中的链接

- 在 `_layout/default.html` 中最后的 script 部分是 Google 的网站分析
- `_layout/post.html` 中最后多说评论和加网分享部分

其余可以在 `_config.yml` 中统一修改。

2014-03-15